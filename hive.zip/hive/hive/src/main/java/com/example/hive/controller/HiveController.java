package com.example.hive.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hive")
public class HiveController {

	private static final Logger logger = LoggerFactory.getLogger(HiveController.class);

	@Autowired
	@Qualifier("hiveJdbcTemplate")
	private JdbcTemplate hiveJdbcTemplate;
	
	//netstat -ano | findstr 8081
	//taskkill /PID <<>> /F

	@RequestMapping("/select")
	public String select() {
		// String sql = "select * from HIVE_TEST";
		String sql = "SELECT * FROM dv_bdfcogsph_gbd_r000_wh.claim_ids LIMIT 100";
		final List<String> cliamIds = hiveJdbcTemplate.query(sql, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {

				return rs.getString("claimid");

			}
		});

		System.out.println(cliamIds);

		/*
		 * Iterator<Map<String, Object>> it = rows.iterator(); while (it.hasNext()) {
		 * Map<String, Object> row = it.next();
		 * System.out.println(String.format("%s\t%s Result", row.get("key"),
		 * row.get("value"))); }
		 */ return "Done";
	}

}
