package com.example.hive;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Hive config class for getCaseDetails microservice
 * 
 * @author AG08087
 *
 */
@Configuration
public class HiveConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(HiveConfig.class);
	
	/**
	 * dv_bdfcogsph_gbd_r000_wh
	 * hive.url=jdbc:hive2://va33tlpsoa001.wellpoint.com:10000/Hive
hive.driver-class-name=org.apache.hive.jdbc.HiveDriver
hive.username=srchdpr
hive.password=Ehub2dcc
	 * @param env
	 * @return
	 */

	@Bean(name = GetCaseDetailsConstants.HIVE_JDBC_DATA_SOURCE)
	//@Qualifier(GetCaseDetailsConstants.HIVE_JDBC_DATA_SOURCE)
	public DataSource dataSource(Environment env) {
		DataSource dataSource = new DataSource();
		dataSource.setUrl("jdbc:hive2://va33tlpsoa001.wellpoint.com:10000/Hive");
		dataSource.setDriverClassName("org.apache.hive.jdbc.HiveDriver");
		dataSource.setUsername("srchdpr");
		dataSource.setPassword("Ehub2dcc");
		logger.debug(GetCaseDetailsConstants.HIVE_DATA_SOURCE);
		return dataSource;
	}

	@Bean(name = GetCaseDetailsConstants.HIVE_JDBC_TEMPLATE)
	public JdbcTemplate hiveJdbcTemplate(@Qualifier(GetCaseDetailsConstants.HIVE_JDBC_DATA_SOURCE) DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}
}
