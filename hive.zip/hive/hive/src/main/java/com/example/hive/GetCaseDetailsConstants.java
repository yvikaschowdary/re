package com.example.hive;

/**
 * GetCaseDetailsConstants is the constant class for this microservice
 * 
 * @author AG08087
 *
 */
public class GetCaseDetailsConstants {
	
	private GetCaseDetailsConstants() {}
	
	public static final String _10S = "%-10s";
	
	public static final String CASE_DTLS_URI =  "/getcasedetails";
	
	public static final String ERRCD_3002 = "3002";
	
	public static final String ERRCD_1002 = "1002";
	
	public static final String ERRCD_3006 = "3006";
	
	public static final String REST_TRANSACTION = "Rest Transaction: Entering getCaseDetailsResponse() --- **Start time ** ";
	
	public static final String ENTERING_GET_CASE_DETAILS_CONTROLLER = "Entering GetCaseDetailsController";

	public static final String EXITING_GET_CASE_DETAILS_CONTROLLER_TIME_TAKEN = "Exiting GetCaseDetailsController <> time taken <>";

	public static final String NO_MBR_GROUP_NBR_RECEIVED_IN_REQUEST = "No MbrGroupNbr received in request";

	public static final String MBR_GROUP_NBR_IS_A_REQUIRED_FIELD = "MbrGroupNbr is a required field";
	
	public static final String MBRGROUPNBR = "mbrgroupnbr";
	
	public static final String VALIDATE_INPUT_ENDS = "validateInput() ends";

	public static final String VALIDATE_INPUT_STARTS = "validateInput() starts";
	
	public static final String HIVE_JDBC_TEMPLATE = "hiveJdbcTemplate";
	
	public static final String HIVE_DATA_SOURCE = "Hive DataSource";
	
	public static final String HIVE_PASSWRD = "hive.password";
	
	public static final String HIVE_USERNAME = "hive.username";
	
	public static final String HIVE_DRIVER_CLASS_NAME = "hive.driver-class-name";
	
	public static final String HIVE_URL = "hive.url";
	
	public static final String HIVE_JDBC_DATA_SOURCE = "hiveJdbcDataSource";
	
	public static final String METHOD_FIND_CASE_DETAILS_ENDS_HERE = "method findCaseDetails() Ends here.";

	public static final String METHOD_FIND_CASE_DETAILS_STARTS_HERE = "method findCaseDetails() Starts here.";
	
	public static final String CS_NATL_ACC_IND = "cs_natl_acc_ind";

	public static final String CS_CONT_ST = "cs_cont_st";

	public static final String ERROR_IN_METHOD_EXECUTE_QUERY_OF_GET_CASE_DETAILS_DAO_CLASS = "Error in method executeQuery() of GetCaseDetailsDAO class : ";

	public static final String EXECUTE_QUERY_OF_GET_CASE_DETAILS_DAO_ENDS_HERE = "executeQuery() of GetCaseDetailsDAO ends here.";

	public static final String EXECUTE_QUERY_OF_GET_CASE_DETAILS_DAO_STARTS_HERE = "executeQuery() of GetCaseDetailsDAO starts here.";
	
	public static final String NO_DATA_FOUND_FOR_GIVEN_GROUP_ID = "No Data Found for given groupId";
	
}
