package com.example.demo.config;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.demo.model.BaseVO;
import com.example.demo.repository.BaseEntity;
import com.example.demo.repository.Claims;
import com.example.demo.task.StudentProcessor;
import com.example.demo.task.StudentWriter;
import com.example.hive.GetCaseDetailsConstants;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	/*
	 * @Bean ItemReader<Student> studentReader() { return new StudentReader(); }
	 */

	/*
	 * @Bean ItemReader<Student> studentReader(DataSource dataSource) {
	 * JdbcCursorItemReader<Student> databaseReader = new JdbcCursorItemReader<>();
	 * 
	 * databaseReader.setDataSource(dataSource); databaseReader.setRowMapper(new
	 * BeanPropertyRowMapper<>(Student.class));
	 * databaseReader.setSql(QUERY_FIND_STUDENTS); databaseReader.setFetchSize(2);
	 * 
	 * return databaseReader; }
	 * 
	 */



	/*
	 * @Bean public JpaPagingItemReader<Student> reader() throws Exception {
	 * JpaPagingItemReader<Student> databaseReader = new JpaPagingItemReader<>();
	 * databaseReader.setEntityManagerFactory(entityManagerFactory);
	 * JpaQueryProviderImpl<Student> jpaQueryProvider = new
	 * JpaQueryProviderImpl<>(); jpaQueryProvider.setQuery("Student.findAll");
	 * databaseReader.setQueryProvider(jpaQueryProvider);
	 * databaseReader.setPageSize(2); databaseReader.afterPropertiesSet(); return
	 * databaseReader; }
	 */

	/*
	 * @Bean(name = "reader")
	 * 
	 * @JobScope public JpaPagingItemReader<BaseEntity>
	 * reader(@Value("#{jobParameters[name]}") String name) throws Exception {
	 * System.out.println(" Name is :" + name); Map<String, Object> paramMap = new
	 * HashMap<>(); paramMap.put("name", name + "%");
	 * JpaPagingItemReader<BaseEntity> reader = new JpaPagingItemReader<>();
	 * reader.setQueryString("SELECT s FROM Student s where s.name like :name");
	 * reader.setParameterValues(paramMap); reader.setPageSize(2);
	 * reader.setEntityManagerFactory(entityManagerFactory); return reader; }
	 */

	/*
	 * @Bean("reader2")
	 * 
	 * @JobScope public JpaPagingItemReader<BaseEntity>
	 * reader2(@Value("#{jobParameters[name]}") String name) throws Exception {
	 * System.out.println(" Name is :" + name); Map<String, Object> paramMap = new
	 * HashMap<>(); paramMap.put("name", name + "%");
	 * JpaPagingItemReader<BaseEntity> reader = new JpaPagingItemReader<>();
	 * reader.setQueryString("SELECT s FROM Employee s where s.name like :name");
	 * reader.setParameterValues(paramMap); reader.setPageSize(2);
	 * reader.setEntityManagerFactory(entityManagerFactory); return reader; }
	 */

	/*
	 * @Bean(name = "reader")
	 * 
	 * @JobScope public JpaPagingItemReader<BaseEntity>
	 * reader(@Value("#{jobParameters[name]}") String name) throws Exception {
	 * System.out.println(" Name is :" + name); Map<String, Object> paramMap = new
	 * HashMap<>(); paramMap.put("name", name + "%");
	 * JpaPagingItemReader<BaseEntity> reader = new JpaPagingItemReader<>();
	 * reader.setQueryString("SELECT * FROM dv_bdfcogsph_gbd_r000_wh.claim_ids");
	 * reader.setParameterValues(paramMap); reader.setPageSize(2);
	 * reader.setEntityManagerFactory(entityManagerFactory.getObject()); return
	 * reader; }
	 */
	@Bean(name = "reader")
	@JobScope
	public JdbcCursorItemReader<BaseEntity> pagingItemReader(@Value("#{jobParameters[name]}") String name,
			DataSource dataSource) throws Exception {
		JdbcCursorItemReader<BaseEntity> reader = new JdbcCursorItemReader<>();

		reader.setDataSource(dataSource);
		
		// reader.setFetchSize(1000);
//		reader.setPageSize(2);
		reader.setSql("SELECT * FROM dv_bdfcogsph_gbd_r000_wh.claim_ids LIMIT 100");
		reader.setRowMapper(new RowMapper<BaseEntity>() {
			@Override
			public BaseEntity mapRow(ResultSet rs, int rowNum) throws SQLException {

				String claimId = rs.getString("claimid");
				Long max = (long) rs.getInt("max_rawz_load_ingstn_id_ci");
				Claims claims = new Claims(claimId, max);
				return claims;

			}
		});

		MySqlPagingQueryProvider queryProvider = new MySqlPagingQueryProvider();
		// queryProvider.setSelectClause("id, firstName, lastName, birthdate");
		queryProvider.setFromClause("from dv_bdfcogsph_gbd_r000_wh.claim_ids");
		// queryProvider.setWhereClause("where id >= " + minValue + " and id <= " +
		// maxValue);

		/*
		 * Map<String, Order> sortKeys = new HashMap<>(1);
		 * 
		 * sortKeys.put("id", Order.ASCENDING);
		 * 
		 * queryProvider.setSortKeys(sortKeys);
		 */

		//reader.setQueryProvider(queryProvider);
		reader.afterPropertiesSet();

		return reader;
	}
	
	@Bean
	//@Qualifier(GetCaseDetailsConstants.HIVE_JDBC_DATA_SOURCE)
	public DataSource dataSource(Environment env) {
		DataSource dataSource = new DataSource();
		dataSource.setUrl("jdbc:hive2://va33tlpsoa001.wellpoint.com:10000/Hive");
		dataSource.setDriverClassName("org.apache.hive.jdbc.HiveDriver");
		dataSource.setUsername("srchdpr");
		dataSource.setPassword("Ehub2dcc");
		return dataSource;
	}

	@Bean
	public JdbcTemplate hiveJdbcTemplate(DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

	@Bean
	ItemProcessor<BaseEntity, BaseVO> studentProcessor() {
		return new StudentProcessor();
	}

	@Bean
	ItemWriter<BaseVO> studentWriter() {
		return new StudentWriter();
	}

	@Bean
	Step step(@Autowired @Qualifier(value = "reader") ItemReader<BaseEntity> studentReader) {
		// .allowStartIfComplete(true)
		return stepBuilderFactory.get("studentStep1").<BaseEntity, BaseVO>chunk(2).reader(studentReader)
				.processor(studentProcessor()).writer(studentWriter()).build();
	}

	/*
	 * @Bean Step step2(@Autowired @Qualifier(value = "reader2")
	 * ItemReader<BaseEntity> studentReader) { // .allowStartIfComplete(true) return
	 * stepBuilderFactory.get("studentStep2").<BaseEntity,
	 * BaseVO>chunk(2).reader(studentReader)
	 * .processor(studentProcessor()).writer(studentWriter()).build(); }
	 */

	@Bean
	// Job job(Step step, @Qualifier(value = "step2") Step step2) {
	Job job(Step step) {
		return jobBuilderFactory.get("studentJob").incrementer(new RunIdIncrementer()).start(step).build();
		// return jobBuilderFactory.get("studentJob").incrementer(new
		// RunIdIncrementer()).start(step).next(step2).build();
	}
}