package com.example.demo.model;

public class ClaimsVO extends BaseVO {

	private static final long serialVersionUID = 1L;

	private String claimId;

	private long maxRawz;
	
	

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public long getMaxRawz() {
		return maxRawz;
	}

	public void setMaxRawz(long maxRawz) {
		this.maxRawz = maxRawz;
	}

	public ClaimsVO() {
		super();
	}

	public ClaimsVO(String claimId, Long count) {
		super();
		this.claimId = claimId;
		this.maxRawz = count;
	}

}
