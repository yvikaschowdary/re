package com.example.demo.repository;

//@Entity
//@Table(name = "claim_ids")
public class Claims extends  BaseEntity{
	
	private static final long serialVersionUID = 1L;
	
	//@Id
	//@Column(name =  "claimid")
	private String claimId;
	
	//@Column(name = "max_rawz_load_ingstn_id_ci")
	private long maxRawz;

	public Claims() {
		super();
	}

	public Claims(String claimId, Long count) {
		super();
		this.claimId = claimId;
		this.maxRawz = count;
	}

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public long getMaxRawz() {
		return maxRawz;
	}

	public void setMaxRawz(long maxRawz) {
		this.maxRawz = maxRawz;
	}
	
	

}
