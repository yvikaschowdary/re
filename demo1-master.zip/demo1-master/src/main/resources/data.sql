insert into student
values(10001,'Rangya', 'E1234567');

insert into student
values(10002,'Raurya', 'A1234568');

insert into student
values(10003,'Radhu', 'A1234569');

insert into student
values(10004,'Bhanu', 'A1234570');

insert into student
values(10005,'Raumya', 'A1234571');

insert into employee
values(10006,'Ratyy', 'A1234572');

insert into employee
values(10007,'Rauuuu', 'A1234573');
